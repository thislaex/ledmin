<?php
ob_start(); 
session_start();

include 'header.php';
include 'sidebar.php';

 ?>

<?php 

if (!isset($_SESSION['uyegiris'])) {
    
    header('Location:login.php');
}

 ?>

<!-- 	INDEX HEART		-->



        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">gAdmin Panel</h1>

                    </div>
                </div>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->

        

<?php include 'footer.php'; ?>

